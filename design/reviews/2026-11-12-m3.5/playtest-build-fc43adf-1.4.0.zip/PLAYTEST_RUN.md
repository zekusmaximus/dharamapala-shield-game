# Run this playtest build

Extract the archive into an empty directory. In that directory, run `python3 -m http.server 8765` and open `http://127.0.0.1:8765/`. A static HTTP server is required; opening index.html as a file is unsupported.

Use a fresh browser profile for each participant. Do not substitute a later build without recording its commit, balance version and save schema. See the accompanying M3.5 facilitator guide for neutral tasks and recording.
